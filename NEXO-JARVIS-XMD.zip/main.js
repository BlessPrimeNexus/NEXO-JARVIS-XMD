// 🧹 Fix for ENOSPC / temp overflow in hosted panels
const fs = require('fs');
const path = require('path');

// Redirect temp storage away from system /tmp
const customTemp = path.join(process.cwd(), 'temp');
if (!fs.existsSync(customTemp)) fs.mkdirSync(customTemp, { recursive: true });
process.env.TMPDIR = customTemp;
process.env.TEMP = customTemp;
process.env.TMP = customTemp;

// Auto-cleaner every 3 hours
setInterval(() => {
    fs.readdir(customTemp, (err, files) => {
        if (err) return;
        for (const file of files) {
            const filePath = path.join(customTemp, file);
            fs.stat(filePath, (err, stats) => {
                if (!err && Date.now() - stats.mtimeMs > 3 * 60 * 60 * 1000) {
                    fs.unlink(filePath, () => { });
                }
            });
        }
    });
    console.log('🧹 Temp folder auto-cleaned');
}, 3 * 60 * 60 * 1000);

const settings = require('./settings');
require('./config.js');
const { isBanned } = require('./lib/isBanned');
const yts = require('yt-search');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const { isSudo } = require('./lib/index');
const isOwnerOrSudo = require('./lib/isOwner');
const ownerAuth = require('./lib/ownerAuth');
const { autotypingCommand, isAutotypingEnabled, handleAutotypingForMessage, handleAutotypingForCommand, showTypingAfterCommand } = require('./commands/autotyping');
const { autoreadCommand, isAutoreadEnabled, handleAutoread } = require('./commands/autoread');

// Command imports
const tagAllCommand = require('./commands/tagall');
const helpCommand = require('./commands/help');
const sessionsCommand = require('./commands/sessions');
const idchCommand = require('./commands/idch');
const addStatutCommand = require('./commands/addstatut');
const fixGroupCommand = require('./commands/fixgroup');
const dlTestCommand = require('./commands/dltest');
const { panelCommand } = require('./commands/panel');
const { utilsCommand, UTILS_COMMANDS } = require('./commands/utils');
const gifCommand = require('./commands/gif');
const pairCommand = require('./commands/pair');
const displayCommand = require('./commands/display');
const viewTestCommand = require('./commands/viewtest');
const { selectedInteractiveId, isInteractiveResponse } = require('./lib/interactiveReply');
const buttonRegistry = require('./lib/buttonRegistry');
const actionsLib = require('./lib/actions');
const extraCommands = require('./lib/extraCommands');
const banCommand = require('./commands/ban');
const { promoteCommand } = require('./commands/promote');
const { demoteCommand } = require('./commands/demote');
const muteCommand = require('./commands/mute');
const { isMuted } = muteCommand;
const unmuteCommand = require('./commands/unmute');
const stickerCommand = require('./commands/sticker');
const isAdmin = require('./lib/isAdmin');
const warnCommand = require('./commands/warn');
const warningsCommand = require('./commands/warnings');
const ttsCommand = require('./commands/tts');
const { tictactoeCommand, handleTicTacToeMove } = require('./commands/tictactoe');
const { incrementMessageCount, topMembers } = require('./commands/topmembers');
const ownerCommand = require('./commands/owner');
const deleteCommand = require('./commands/delete');
const { handleAntilinkCommand, handleLinkDetection } = require('./commands/antilink');
const { handleAntitagCommand, handleTagDetection } = require('./commands/antitag');
const { Antilink } = require('./lib/antilink');
const { handleMentionDetection, mentionToggleCommand, setMentionCommand } = require('./commands/mention');
const memeCommand = require('./commands/meme');
const tagCommand = require('./commands/tag');
const tagNotAdminCommand = require('./commands/tagnotadmin');
const hideTagCommand = require('./commands/hidetag');
const jokeCommand = require('./commands/joke');
const quoteCommand = require('./commands/quote');
const factCommand = require('./commands/fact');
const weatherCommand = require('./commands/weather');
const newsCommand = require('./commands/news');
const kickCommand = require('./commands/kick');
const simageCommand = require('./commands/simage');
const attpCommand = require('./commands/attp');
const { startHangman, guessLetter } = require('./commands/hangman');
const { startTrivia, answerTrivia } = require('./commands/trivia');
const { complimentCommand } = require('./commands/compliment');
const { insultCommand } = require('./commands/insult');
const { eightBallCommand } = require('./commands/eightball');
const { lyricsCommand } = require('./commands/lyrics');
const { dareCommand } = require('./commands/dare');
const { truthCommand } = require('./commands/truth');
const { clearCommand } = require('./commands/clear');
const pingCommand = require('./commands/ping');
const aliveCommand = require('./commands/alive');
const blurCommand = require('./commands/img-blur');
const { welcomeCommand, handleJoinEvent } = require('./commands/welcome');
const { goodbyeCommand, handleLeaveEvent } = require('./commands/goodbye');
const githubCommand = require('./commands/github');
const repoCommand   = require('./commands/repo');
const { handleAntiBadwordCommand, handleBadwordDetection } = require('./lib/antibadword');
const antibadwordCommand = require('./commands/antibadword');
const { handleChatbotCommand, handleChatbotResponse } = require('./commands/chatbot');
const takeCommand = require('./commands/take');
const { flirtCommand } = require('./commands/flirt');
const characterCommand = require('./commands/character');
const wastedCommand = require('./commands/wasted');
const shipCommand = require('./commands/ship');
const groupInfoCommand = require('./commands/groupinfo');
const profileCommand = require('./commands/profile');
const { handleHijackCommand, restoreHijackTimers } = require('./commands/hijack');
const resetlinkCommand = require('./commands/resetlink');
const staffCommand = require('./commands/staff');
const unbanCommand = require('./commands/unban');
const emojimixCommand = require('./commands/emojimix');
const { handlePromotionEvent } = require('./commands/promote');
const { handleDemotionEvent } = require('./commands/demote');
// viewOnceCommand remplacé par vvCommand (voir import ci-dessous)
const clearSessionCommand = require('./commands/clearsession');
const { autoStatusCommand, handleStatusUpdate } = require('./commands/autostatus');
const { simpCommand } = require('./commands/simp');
const { stupidCommand } = require('./commands/stupid');
const stickerTelegramCommand = require('./commands/stickertelegram');
const textmakerCommand = require('./commands/textmaker');
const { handleAntideleteCommand, handleMessageRevocation, storeMessage } = require('./commands/antidelete');
const clearTmpCommand = require('./commands/cleartmp');
const setProfilePicture = require('./commands/setpp');
const { setGroupDescription, setGroupName, setGroupPhoto } = require('./commands/groupmanage');
const instagramCommand = require('./commands/instagram');
const facebookCommand = require('./commands/facebook');
const spotifyCommand = require('./commands/spotify');
const playCommand = require('./commands/play');
const tiktokCommand = require('./commands/tiktok');
const songCommand = require('./commands/song');
const ytdlCommand = require('./commands/ytdl');
const themeCommand = require('./commands/theme');
const { withProgress } = require('./lib/withProgress');
const aiCommand = require('./commands/ai');
const urlCommand = require('./commands/url');
const { handleTranslateCommand } = require('./commands/translate');
const { handleSsCommand } = require('./commands/ss');
const { addCommandReaction, addAllMessageReaction, handleAreactCommand } = require('./lib/reactions');
const { goodnightCommand } = require('./commands/goodnight');
const { shayariCommand } = require('./commands/shayari');
const { rosedayCommand } = require('./commands/roseday');
const imagineCommand = require('./commands/imagine');
const videoCommand = require('./commands/video');
const sudoCommand = require('./commands/sudo');
const { miscCommand, handleHeart } = require('./commands/misc');
const { animeCommand } = require('./commands/anime');
const { piesCommand, piesAlias } = require('./commands/pies');
const stickercropCommand = require('./commands/stickercrop');
const updateCommand = require('./commands/update');
const removebgCommand = require('./commands/removebg');
const { reminiCommand } = require('./commands/remini');
const { igsCommand } = require('./commands/igs');
const { anticallCommand, readState: readAnticallState } = require('./commands/anticall');
const { pmblockerCommand, readState: readPmBlockerState } = require('./commands/pmblocker');
const settingsCommand = require('./commands/settings');
const statsCommand = require('./commands/stats');
const { isCommandEnabled } = require('./lib/sessionSettings');
const soraCommand = require('./commands/sora');
const { antibotCommand, isAntibotEnabled, handleAntibot } = require('./commands/antibot');
const antibotEngine = require('./lib/antibot');
const { promoteTimeCommand } = require('./commands/promotetime');
const { kickTimeCommand } = require('./commands/kicktime');
const { deleteAllCommand } = require('./commands/deleteall');
const { openGroupCommand, closeGroupCommand } = require('./commands/openclose');
const { kickAllCommand } = require('./commands/kickall');
const { kickAll2Command } = require('./commands/kickall2');
const { groupAntiCommand, handleGroupAnti } = require('./commands/groupanti');
const vvCommand = require('./commands/viewonce');
const { antiPromoteCommand, handleAntiPromoteEvent } = require('./commands/antipromote');
const { antiMentionGcCommand, handleAntiMentionGc } = require('./commands/antimentiongc');
const { getPrefix, normalizeCommandText, setPrefix } = require('./lib/prefix');
const { setCmdCommand, dispatchCustomCommand } = require('./commands/customcmd');
const { GROUP_COMMANDS, handleGroupExtraCommand } = require('./commands/groupExtras');
const fakeReactCommand = require('./commands/fakeract');
const { parseMenuCommand } = require('./lib/menu-command');

// Global settings
global.packname = settings.packname;
global.author = settings.author;
global.ytch = "";

// Add this near the top of main.js with other global configurations
const { channelInfo } = require('./lib/messageConfig'); // JID de la chaîne résolu automatiquement (lib/channel.js)
const SESSION_EXEMPT_COMMANDS = new Set([
    '.settings', '.stats', '.sessions', '.session', '.delsession', '.menu', '.help', '.allmenu', '.list', '.bot'
]);

function readBotMode() {
    try {
        const data = JSON.parse(fs.readFileSync('./data/messageCount.json', 'utf8'));
        return data.isPublic !== false;
    } catch (error) {
        console.error('Error checking access mode:', error);
        return true;
    }
}

function unwrapMessageContent(content) {
      let current = content;
      for (let index = 0; index < 8; index += 1) {
          const next = current?.ephemeralMessage?.message
              || current?.viewOnceMessage?.message
              || current?.viewOnceMessageV2?.message
              || current?.viewOnceMessageV2Extension?.message
              || current?.documentWithCaptionMessage?.message
              || current?.editedMessage?.message;
          if (!next || next === current) break;
          current = next;
      }
      return current;
    }

    async function handleMessages(sock, messageUpdate, printLog) {
    let chatId = '';
    try {
        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;

        let message = messages[0];
          if (!message?.message) return;
          message = {
              ...message,
              message: unwrapMessageContent(message.message)
          };
          if (!message.message) return;
    
        // Handle autoread functionality
        await handleAutoread(sock, message);

        // Store message for antidelete feature
        if (message.message) {
            storeMessage(sock, message);
        }

        // Handle message revocation
        if (message.message?.protocolMessage?.type === 0) {
            await handleMessageRevocation(sock, message);
            return;
        }

        chatId = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;
        const isGroup = chatId.endsWith('@g.us');
        const senderIsSudo = await isSudo(senderId);
        // Contrôle propriétaire STRICT (lib/ownerAuth.js) : numéros listés dans settings.ownerNumbers, LID traduits,
        // et un message envoyé depuis une autre session connectée ne vaut jamais « propriétaire ».
        const senderIsPlatformOwner = await ownerAuth.isPlatformOwnerMessage(sock, message, chatId);
        const senderIsPrimaryOwner = senderIsPlatformOwner || await ownerAuth.isOwnerMessage(sock, message, chatId);
        const senderIsOwnerOrSudo = await ownerAuth.isOwnerOrSudoMessage(sock, message, chatId);
        if (isGroup) require('./lib/messageLog').record(chatId, message);   // journal des messages vus (pour .del)
        const configuredOwner = String(settings.ownerNumber || '').replace(/\D/g, '');
        const senderNumbers = [senderId, message.key.participantAlt, message.key.remoteJid].filter(Boolean).map(value => String(value).split('@')[0].split(':')[0].replace(/\D/g, ''));
        const botNumberForOwner = String(sock.user?.id || '').split(':')[0].split('@')[0].replace(/\D/g, '');
        const isConfiguredOwner = senderNumbers.includes(configuredOwner) || (message.key.fromMe && botNumberForOwner === configuredOwner);

        // Suppression des messages des utilisateurs ciblés par .mute @user.
        if (isGroup && !message.key.fromMe && isMuted(chatId, senderId)) {
            try {
                await sock.sendMessage(chatId, {delete: message.key});
            } catch (error) {
                console.error('[mute] impossible de supprimer le message:', error.message);
            }
            return;
        }


        // Antibot : détecte les messages des autres bots (ID Baileys, boutons natifs, aperçu pub, bots appris),
        // les supprime (ou retire le bot selon .antibot mode) et s'arrête : aucune autre fonction ne leur répond.
        if (isGroup && !message.key.fromMe) {
            try {
                if (await handleAntibot(sock, chatId, message, senderId, { senderIsOwnerOrSudo })) return;
            } catch (error) {
                console.error('[antibot] erreur :', error.message);
            }
        }
        // Message d'un AUTRE bot Baileys (ID « BAE5… ») : jamais traité comme une commande ni comme une discussion
        // (évite les boucles bot ↔ bot). Les anciens filtres de botInstance.js les jetaient avant ce point.
        if (antibotEngine.isForeignBaileysId(message)) return;

        // Native Flow clients return the selected action in paramsJson.
        // Decode it here so cta_copy remains useful even when WhatsApp sends a
        // nativeFlow response instead of the older template-button shape.
        const nativeFlow = message.message?.interactiveResponseMessage?.nativeFlowResponseMessage;
        if (nativeFlow) {
            let params = {};
            try { params = JSON.parse(nativeFlow.paramsJson || '{}'); } catch {}
            if (nativeFlow.name === 'cta_copy' || params.copy_code) {
                const copiedUrl = String(params.copy_code || params.url || '').trim();
                try {
                    new URL(copiedUrl);
                    await sock.sendMessage(message.key.remoteJid, { text: copiedUrl }, { quoted: message });
                } catch {
                    // Copie d'autre chose qu'un lien (ex. JID de .idch) : le téléphone l'a déjà copié, rien à répondre.
                }
                return;
            }
            if (nativeFlow.name === 'cta_url') return;
        }

        // Handle URL copy buttons from url.js. The URL stays hidden until the user presses Copy Link.
        const templateButtonId = message.message?.templateButtonReplyMessage?.selectedId?.trim();
        if (templateButtonId?.startsWith('url_copy:')) {
            if (!readBotMode() && !senderIsOwnerOrSudo) return;
            try {
                const encodedUrl = templateButtonId.slice('url_copy:'.length);
                const copiedUrl = Buffer.from(encodedUrl, 'base64url').toString('utf8');
                new URL(copiedUrl);
                await sock.sendMessage(message.key.remoteJid, { text: copiedUrl }, { quoted: message });
            } catch {
                await sock.sendMessage(message.key.remoteJid, { text: '❌ Le lien à copier est invalide.' }, { quoted: message });
            }
            return;
        }

        // Handle button responses
        if (message.message?.buttonsResponseMessage) {
            // Private mode also blocks interactive menu actions for non-owners.
            if (!readBotMode() && !senderIsOwnerOrSudo) return;
            const buttonId = message.message.buttonsResponseMessage.selectedButtonId;
            const chatId = message.key.remoteJid;

            if (buttonId === 'channel' || buttonId === 'support') {
                await sock.sendMessage(chatId, {
                    text: '✅ Le compte connecté est automatiquement ajouté aux espaces officiels NEXO-JARVIS.'
                }, { quoted: message });
                return;
            } else if (buttonId === 'owner') {
                const ownerCommand = require('./commands/owner');
                await ownerCommand(sock, chatId, message);
                return;
            }
        }

        const rawTextFromMessage = (
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            message.message?.buttonsResponseMessage?.selectedButtonId?.trim() ||
            selectedInteractiveId(message, (title) => helpCommand.resolveMenuChoice?.(title, getPrefix(chatId))) ||
            ''
        );
        // Certains téléphones n'envoient que le TEXTE du bouton touché (« 🔄 Actualiser »), sans la commande :
        // on la retrouve grâce au registre des boutons envoyés (ou aux boutons fixes connus d'avance).
        let rawText = rawTextFromMessage;
        const clickedCommand = !rawTextFromMessage.startsWith(getPrefix(chatId))
            ? buttonRegistry.resolve(message, chatId) : '';
        if (clickedCommand) {
            const prefix = getPrefix(chatId);
            rawText = clickedCommand.startsWith('.') ? `${prefix}${clickedCommand.slice(1)}` : clickedCommand;
            console.log(`[bouton] « ${rawTextFromMessage || 'texte seul'} » → ${rawText}`);
        } else if (isInteractiveResponse(message) && !rawTextFromMessage) {
            console.log('[bouton] réponse de bouton non reconnue :', JSON.stringify(message.message).slice(0, 400));
        }
        // Owner-friendly diagnostic alias. It reports only the active scope
        // (this private chat or this group), never another user's chat data.
        if (/^>\s+prefixe?\s*$/i.test(rawText) && senderIsPrimaryOwner) {
            await sock.sendMessage(chatId, {
                text: `🔑 Préfixe actif pour cette discussion : ${getPrefix(chatId)}`,
                ...channelInfo
            }, { quoted: message });
            return;
        }
        // Internally, commands use "." only after the active prefix has been
        // matched. A configured prefix fully replaces the default ".".
        const activePrefix = getPrefix(chatId);
        const userMessage = normalizeCommandText(rawText, activePrefix);

        // Un clic sur un bouton / une ligne de liste n'arrive PAS comme un texte : beaucoup de commandes (welcome,
        // goodbye, antilink set…) relisent leurs arguments dans message.message. On remplace donc la réponse de bouton
        // par le texte de la commande choisie : elles voient exactement ce que la personne aurait tapé.
        if (rawText && (isInteractiveResponse(message) || clickedCommand) && message.message) {
            const original = message.message.interactiveResponseMessage?.contextInfo
                || message.message.buttonsResponseMessage?.contextInfo
                || message.message.listResponseMessage?.contextInfo
                || message.message.templateButtonReplyMessage?.contextInfo
                || {};
            message.message = {
                extendedTextMessage: {
                    text: rawText,
                    contextInfo: original.mentionedJid ? { mentionedJid: original.mentionedJid } : {}
                }
            };
        }
        if (isInteractiveResponse(message)) {
            console.log(`[menu] Choix reçu depuis un bouton : « ${rawText || 'illisible'} »`);
        }

        if (rawText.startsWith(activePrefix) && (userMessage === '.prefix' || userMessage === '.prefixe')) {
            await sock.sendMessage(chatId, {
                text: `🔑 Préfixe actif pour cette discussion : ${getPrefix(chatId)}`,
                ...channelInfo
            }, { quoted: message });
            return;
        }

        // Only log command usage
        if (rawText.startsWith(activePrefix) && userMessage.startsWith('.')) {
            console.log(`📝 Command used in ${isGroup ? 'group' : 'private'}: ${userMessage}`);
        }
        // Read bot mode once. Private mode is a hard owner/sudo lock.
        const isPublic = readBotMode();
        const isOwnerOrSudoCheck = senderIsOwnerOrSudo;
        // Check if user is banned (skip ban check for unban command)
        if (isBanned(senderId) && !userMessage.startsWith('.unban')) {
            // Only respond occasionally to avoid spam
            if (Math.random() < 0.1) {
                await sock.sendMessage(chatId, {
                    text: '❌ Vous êtes banni de ce système, Monsieur. Contactez un administrateur pour être rétabli.',
                    ...channelInfo
                });
            }
            return;
        }

        // Private mode must block every bot feature for everyone else:
        // commands, games, chatbot responses and plain-text menu aliases.
        if (!isPublic && !isOwnerOrSudoCheck) return;

        // Route bare and prefixed menu aliases through one parser before
        // moderation/non-command handling; this avoids duplicate menu routes.
        const hasActivePrefix = rawText.startsWith(activePrefix);
        const menuRequest = parseMenuCommand(userMessage, { prefixed: hasActivePrefix });
        if (menuRequest) {
            if (hasActivePrefix) {
                const sessionNumber = String(sock.user?.id || '').split(':')[0].split('@')[0].replace(/\D/g, '');
                const menuCommandToken = userMessage.split(/\s+/)[0].toLowerCase();
                if (
                    !SESSION_EXEMPT_COMMANDS.has(menuCommandToken) &&
                    !isCommandEnabled(sessionNumber, menuCommandToken)
                ) {
                    await sock.sendMessage(chatId, {
                        text: `⛔ La commande ${menuCommandToken} est désactivée pour cette session.`
                    }, { quoted: message });
                    return;
                }
            }
            await helpCommand(sock, chatId, message, menuRequest.query);
            return;
        }

        // First check if it's a game move
        if (/^[1-9]$/.test(userMessage) || userMessage.toLowerCase() === 'surrender') {
            await handleTicTacToeMove(sock, chatId, senderId, userMessage);
            return;
        }

        /*  // Basic message response in private chat
          if (!isGroup && (userMessage === 'hi' || userMessage === 'hello' || userMessage === 'bot' || userMessage === 'hlo' || userMessage === 'hey' || userMessage === 'bro')) {
              await sock.sendMessage(chatId, {
                  text: 'Hi, How can I help you?\nYou can use .menu for more info and commands.',
                  ...channelInfo
              });
              return;
          } */

        if (!message.key.fromMe) incrementMessageCount(chatId, senderId);

        // Check for bad words and antilink FIRST, before ANY other processing
        // Always run moderation in groups, regardless of mode
        if (isGroup) {
            if (userMessage) {
                await handleBadwordDetection(sock, chatId, message, userMessage, senderId);
            }
            // Antilink checks message text internally, so run it even if userMessage is empty
            await Antilink(message, sock);
            // Anti-mention-gc : supprime les messages mentionnant le groupe
            if (await handleAntiMentionGc(sock, chatId, message, senderId)) return;
            if (await handleGroupAnti(sock, chatId, message, senderId)) return;
        }

        // PM blocker: block non-owner DMs when activé (do not ban)
        if (!isGroup && !message.key.fromMe && !senderIsOwnerOrSudo) {
            try {
                const pmState = readPmBlockerState();
                if (pmState.activé) {
                    // Inform user, delay, then block without banning globally
                    await sock.sendMessage(chatId, { text: pmState.message || 'Les messages privés sont désactivés. Veuillez contacter le propriétaire dans un groupe.' });
                    await new Promise(r => setTimeout(r, 1500));
                    try { await sock.updateBlockStatus(chatId, 'block'); } catch (e) { }
                    return;
                }
            } catch (e) { }
        }

        // Then check for command prefix
        if (!rawText.startsWith(activePrefix)) {
            // Show typing indicator if autotyping is activé
            await handleAutotypingForMessage(sock, chatId, userMessage);

            // ── Autoreact sur TOUS les messages (groupes + PV) quand activé ──
            // Indépendant des commandes — réagit à chaque message entrant
            if (!message.key.fromMe) {
                addAllMessageReaction(sock, message).catch(() => {});
            }

            if (isGroup) {
                // Always run moderation features (antitag) regardless of mode
                await handleTagDetection(sock, chatId, message, senderId);
                await handleMentionDetection(sock, chatId, message);

                // Only run chatbot in public mode or for owner/sudo
                if (isPublic || isOwnerOrSudoCheck) {
                    await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                }
            }
            return;
        }
        const sessionNumber = String(sock.user?.id || '').split(':')[0].split('@')[0].replace(/\D/g, '');
        const commandToken = userMessage.split(/\s+/)[0].toLowerCase();
        if (!SESSION_EXEMPT_COMMANDS.has(commandToken) && !isCommandEnabled(sessionNumber, commandToken)) {
            await sock.sendMessage(chatId, { text: '⛔ La commande ' + commandToken + ' est désactivée pour cette session.' }, { quoted: message });
            return;
        }

        // List of admin commands
        const commandMatches = cmd => userMessage === cmd || userMessage.startsWith(`${cmd} `);
        const adminCommands = ['.mute', '.unmute', '.ban', '.unban', '.promote', '.demote', '.demoteadmin', '.kick', '.kicktime', '.kickall', '.kickall2', '.tagnotadmin', '.hidetag', '.antilink', '.antitag', '.antibot', '.antibadword', '.antipromote', '.antimentiongc', '.antiflood', '.antispam', '.antimedia', '.antisticker', '.antivoice', '.setgdesc', '.setgname', '.setgpp', '.deleteall', '.open', '.close'];
        // Seules les opérations qui modifient réellement WhatsApp exigent que
        // le compte connecté soit admin. Les commandes de mention et de
        // configuration locale continuent de fonctionner sans ce droit.
        const botAdminCommands = ['.mute', '.ban', '.promote', '.demote', '.demoteadmin', '.kick', '.kicktime', '.kickall', '.kickall2', '.antilink', '.antitag', '.antibot', '.antibadword', '.antipromote', '.antimentiongc', '.antiflood', '.antispam', '.antimedia', '.antisticker', '.antivoice', '.setgdesc', '.setgname', '.setgpp', '.deleteall', '.open', '.close'];
        const isAdminCommand = adminCommands.some(commandMatches);
        const isBotAdminRequired = botAdminCommands.some(commandMatches);

        // List of owner commands
        // Réservées au propriétaire (le contrôle central refuse tout autre expéditeur avant même d'exécuter la commande).
        const STRICT_OWNER_ONLY = ['.dltest', '.panel', '.ram', '.gc', '.logs', '.disk', '.restart', '.config', '.owners', '.lang', '.sessions', '.session', '.delsession', '.sessionlist', '.listsessions', '.sudo', '.update', '.clearsession', '.settings', '.stats', '.viewtest', '.menustyle', '.theme', '.themes', '.imagemode', '.replystyle', '.preview', '.quotecard', '.mode', '.fakeract', '.channelalert'];
        const ownerCommands = ['.mode', '.autostatus', '.antidelete', '.cleartmp', '.setpp', '.clearsession', '.areact', '.autoreact', '.autotyping', '.autoread', '.pmblocker', '.update', ...STRICT_OWNER_ONLY];
        const isOwnerCommand = ownerCommands.some(commandMatches);
        const isChannelAlertCommand = commandMatches('.fakeract') || commandMatches('.channelalert');

        let isSenderAdmin = false;
        let isBotAdmin = false;

        // Check admin status only for admin commands in groups
        if (isGroup && isAdminCommand) {
            // Si c'est le propriétaire (fromMe ou ownerOrSudo), on bypass toutes les vérifications
            if (message.key.fromMe || senderIsOwnerOrSudo) {
                isSenderAdmin = true;
                isBotAdmin = true;
            } else {
                const adminStatus = await isAdmin(sock, chatId, senderId);
                isSenderAdmin = adminStatus.isSenderAdmin;
                isBotAdmin = adminStatus.isBotAdmin;

                if (isBotAdminRequired && !isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: '⚠️ Cette action WhatsApp nécessite que le compte connecté soit administrateur du groupe.',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }

                if (
                    commandMatches('.mute') ||
                    commandMatches('.unmute') ||
                    commandMatches('.ban') ||
                    commandMatches('.unban') ||
                    commandMatches('.promote') ||
                    commandMatches('.demote') ||
                    commandMatches('.demoteadmin') ||
                    commandMatches('.kickall') || commandMatches('.kickall2')
                ) {
                    if (!isSenderAdmin) {
                        await sock.sendMessage(chatId, {
                            text: 'Seuls les admins peuvent utiliser cette commande.',
                            ...channelInfo
                        }, { quoted: message });
                        return;
                    }
                }
            }
        }

        // Check owner status for owner commands
        if (isOwnerCommand) {
            // Commandes de la PLATEFORME (redémarrage, mises à jour, sessions, ressources) : développeur uniquement.
            // Les réglages du bot (mode, langue, préfixe…) restent à la portée du propriétaire de la session.
            const PLATFORM_ONLY = ['.dltest', '.panel', '.ram', '.gc', '.logs', '.disk', '.restart', '.config', '.sessions', '.session', '.delsession', '.sessionlist', '.listsessions', '.update', '.clearsession', '.viewtest', '.sendall', '.notifyall'];
            if (PLATFORM_ONLY.some(commandMatches) && !senderIsPlatformOwner) {
                await sock.sendMessage(chatId, { text: '⛔ Cette commande est réservée à l\'administrateur de la plateforme.' }, { quoted: message });
                return;
            }
            if (!senderIsPrimaryOwner && !(senderIsOwnerOrSudo && !STRICT_OWNER_ONLY.some(commandMatches))) {
                await sock.sendMessage(chatId, { text: '⛔ Cette commande est réservée au propriétaire du bot.' }, { quoted: message });
                return;
            }
        }
        if (isChannelAlertCommand && !message.key.fromMe) {
            await sock.sendMessage(chatId, {
                text: '❌ Activez les notifications depuis le compte WhatsApp connecté auquel vous souhaitez les appliquer.',
                ...channelInfo
            }, { quoted: message });
            return;
        }

        // Command handlers - Execute commands immediately without waiting for typing indicator
        // We'll show typing indicator after command execution if needed
        let commandExecuted = false;

        // Réagir dès qu'une commande est reconnue, y compris pour les
        // commandes custom et les protections qui sortent plus tôt.
        const _cmdKey = userMessage.split(/\s+/)[0];
        addCommandReaction(sock, message, _cmdKey).catch(() => {});

        // Boutons d'action sur TOUTES les réponses de commande : réglages de la commande (antilink, welcome, mode…) ou,
        // à défaut, actions de sa catégorie (relancer, commandes voisines, menu de la catégorie, menu principal).
        {
            const actionCommand = actionsLib.commandNameOf(userMessage);
            if (userMessage.startsWith('.') && actionCommand) {
                sock = actionsLib.wrapSock(sock, {
                    chatId, message, command: actionCommand,
                    args: rawText.trim().split(/\s+/).slice(1).join(' ')
                });
            }
        }

        // Custom sticker commands are checked before the large legacy switch.
        // This keeps setcmd extensible without adding generated case labels.
        const customCommandName = userMessage.match(/^\.([a-z0-9_-]+)/)?.[1] || '';
        if (isGroup && customCommandName === 'hijack') {
            await handleHijackCommand(
                sock,
                chatId,
                message,
                userMessage.slice('.hijack'.length).trim().split(/\s+/).filter(Boolean),
                senderIsOwnerOrSudo
            );
            commandExecuted = true;
            sock.sendPresenceUpdate('paused', chatId).catch(() => {});
            return;
        }

        if (customCommandName && customCommandName !== 'setcmd') {
            if (await dispatchCustomCommand(sock, chatId, message, customCommandName)) {
                commandExecuted = true;
                sock.sendPresenceUpdate('paused', chatId).catch(() => {});
                return;
            }
        }

        if (userMessage === '.setprefix' || userMessage.startsWith('.setprefix ')) {
            const requestedPrefix = userMessage.slice('.setprefix'.length).trim();
            // Prefixes are scoped to this chat, so every user can configure
            // their own private chat without changing other conversations.
            // In groups, the chosen prefix only affects this group.
            if (!requestedPrefix) {
                await sock.sendMessage(chatId, { text: `ℹ️ Préfixe actuel : ${getPrefix(chatId)}\nUtilisez .setprefix ! ou .setprefix 🔥`, ...channelInfo }, { quoted: message });
                return;
            }
            try {
                const prefix = setPrefix(chatId, requestedPrefix);
                await sock.sendMessage(chatId, { text: `✅ Préfixe configuré : ${prefix}\nExemple : ${prefix}menu`, ...channelInfo }, { quoted: message });
            } catch (error) {
                await sock.sendMessage(chatId, { text: `❌ ${error.message}`, ...channelInfo }, { quoted: message });
            }
            return;
        }

        if (userMessage === '.setcmd' || userMessage.startsWith('.setcmd ')) {
            if (isGroup) {
                const setcmdStatus = await isAdmin(sock, chatId, senderId);
                if (!setcmdStatus.isSenderAdmin && !senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, { text: '❌ Seuls les admins peuvent créer une commande sticker.', ...channelInfo }, { quoted: message });
                    return;
                }
            } else if (!senderIsOwnerOrSudo) {
                await sock.sendMessage(chatId, { text: '❌ Cette commande est réservée au propriétaire en privé.', ...channelInfo }, { quoted: message });
                return;
            }
            try {
                await setCmdCommand(sock, chatId, message, userMessage.slice('.setcmd'.length).trim().split(/\s+/).filter(Boolean));
            } catch (error) {
                await sock.sendMessage(chatId, { text: `❌ Impossible de créer la commande : ${error.message}`, ...channelInfo }, { quoted: message });
            }
            return;
        }

        if (isGroup && GROUP_COMMANDS.includes(customCommandName)) {
            await handleGroupExtraCommand(
                sock,
                chatId,
                message,
                customCommandName,
                userMessage.slice(`.${customCommandName}`.length).trim().split(/\s+/).filter(Boolean),
                senderIsOwnerOrSudo
            );
            commandExecuted = true;
            sock.sendPresenceUpdate('paused', chatId).catch(() => {});
            return;
        }


        // Commandes complémentaires (économie, santé, cyber, notes, diffusion, apk, religion…).
        if (customCommandName && extraCommands.has(customCommandName)) {
            await extraCommands.run(customCommandName, {
                sock, chatId, message, senderId, isOwner: senderIsOwnerOrSudo, isPlatformOwner: senderIsPlatformOwner,
                args: rawText.trim().split(/\s+/).slice(1)
            });
            sock.sendPresenceUpdate('paused', chatId).catch(() => {});
            return;
        }

        // ── Typing presence: "En train d'écrire…" while processing ──────────
        sock.sendPresenceUpdate('composing', chatId).catch(() => {});

        switch (true) {
            case userMessage === '.simage': {
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                if (quotedMessage?.stickerMessage) {
                    await simageCommand(sock, quotedMessage, chatId);
                } else {
                    await sock.sendMessage(chatId, { text: 'Répondez à un sticker avec la commande .simage pour le convertir.', ...channelInfo }, { quoted: message });
                }
                commandExecuted = true;
                break;
            }
            // ── .kickall doit être AVANT .kick pour éviter le court-circuit ──
            case userMessage === '.kickall2':
                await kickAll2Command(sock, chatId, senderId, message);
                break;
            case userMessage === '.kickall':
                await kickAllCommand(sock, chatId, senderId, message);
                break;
            // ── .kicktime doit être AVANT .kick ──
            case userMessage.startsWith('.kicktime'):
                await kickTimeCommand(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.kick'):
                const mentionedJidListKick = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await kickCommand(sock, chatId, senderId, mentionedJidListKick, message);
                break;
            case commandMatches('.mute'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const mentionedJidListMute = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    const extraArgs = parts.slice(1).filter(arg => !arg.startsWith('@'));
                    const durationArg = extraArgs.find(arg => /^\d+$/.test(arg));
                    const hasInvalidArg = extraArgs.some(arg => !/^\d+$/.test(arg));
                    const muteDuration = durationArg ? parseInt(durationArg, 10) : undefined;
                    if (hasInvalidArg || (durationArg && muteDuration <= 0)) {
                        await sock.sendMessage(chatId, { text: '❌ Utilisez .mute @user [minutes] ou répondez à son message avec .mute.', ...channelInfo }, { quoted: message });
                    } else {
                        await muteCommand(sock, chatId, senderId, message, muteDuration, mentionedJidListMute);
                    }
                }
                break;
            case commandMatches('.unmute'):
                {
                    const mentionedJidListUnmute = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await unmuteCommand(sock, chatId, senderId, message, mentionedJidListUnmute);
                }
                break;
            case userMessage.startsWith('.ban'):
                if (!isGroup) {
                    if (!senderIsOwnerOrSudo) {
                        await sock.sendMessage(chatId, { text: 'Réservé au propriétaire ou aux sudo en conversation privée, Monsieur.' }, { quoted: message });
                        break;
                    }
                }
                await banCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.unban'):
                if (!isGroup) {
                    if (!senderIsOwnerOrSudo) {
                        await sock.sendMessage(chatId, { text: 'Réservé au propriétaire ou aux sudo en conversation privée, Monsieur..' }, { quoted: message });
                        break;
                    }
                }
                await unbanCommand(sock, chatId, message);
                break;
            case userMessage === '.sticker' || userMessage === '.s':
                await stickerCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.warnings'):
                const mentionedJidListWarnings = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warningsCommand(sock, chatId, mentionedJidListWarnings);
                break;
            case userMessage.startsWith('.warn'):
                const mentionedJidListWarn = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await warnCommand(sock, chatId, senderId, mentionedJidListWarn, message);
                break;
            case userMessage.startsWith('.tts'):
                const text = userMessage.slice(4).trim();
                await ttsCommand(sock, chatId, text, message);
                break;
            // ── .deleteall doit être AVANT .delete ──
            case userMessage === '.deleteall':
                await deleteAllCommand(sock, chatId, senderId, message);
                break;
            case userMessage === '.del' || userMessage.startsWith('.del ') || userMessage === '.delete' || userMessage.startsWith('.delete '):
                await deleteCommand(sock, chatId, message, senderId);
                break;
            case userMessage.startsWith('.attp'):
                await attpCommand(sock, chatId, message);
                break;

            case userMessage === '.settings':
            case userMessage.startsWith('.settings '):
                await settingsCommand(sock, chatId, message, userMessage.slice('.settings'.length).trim());
                break;
            case userMessage === '.sessions' || userMessage.startsWith('.sessions ') || userMessage === '.session' || userMessage.startsWith('.session ')
                || userMessage === '.sessionlist' || userMessage === '.listsessions': {
                const sessionArgs = userMessage.replace(/^\.(sessions|session|sessionlist|listsessions)\s*/, '');
                await sessionsCommand(sock, chatId, message, sessionArgs);
                break;
            }
            case userMessage.startsWith('.delsession'):
                await sessionsCommand(sock, chatId, message, `remove ${userMessage.slice('.delsession'.length).trim()}`);
                break;
            case userMessage === '.stats':
                await statsCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.mode'):
                // Check if sender is the owner
                if (!senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, {
                        text:
                            `╭─〔 𝗡𝗘𝗫𝗢-𝗝𝗔𝗥𝗩𝗜𝗦 𝗔𝗖𝗖𝗘𝗦𝗦 〕─╮\n` +
                            `│ ❌ *ACCESS DENIED*\n` +
                            `│ Cette commande est réservée\n` +
                            `│ au propriétaire ou aux sudo.\n` +
                            `╰──────────────────╯`,
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                // Read current data first
                let data;
                try {
                    data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
                } catch (error) {
                    console.error('Error reading access mode:', error);
                    await sock.sendMessage(chatId, {
                        text: '╭─〔 𝗡𝗘𝗫𝗢-𝗝𝗔𝗥𝗩𝗜𝗦 𝗔𝗖𝗖𝗘𝗦𝗦 〕─╮\n│ ❌ Impossible de lire le mode.\n╰──────────────────╯',
                        ...channelInfo
                    });
                    return;
                }

                const action = userMessage.split(' ')[1]?.toLowerCase();
                // If no argument provided, show current status
                if (!action) {
                    const currentMode = data.isPublic ? 'PUBLIC' : 'PRIVATE';
                    const accessInfo = data.isPublic
                        ? '🌐 Tout le monde peut utiliser le bot.'
                        : '🔒 Accès réservé au propriétaire et aux sudo autorisés.';
                    await sock.sendMessage(chatId, {
                        text:
                            `╭─〔 𝗡𝗘𝗫𝗢-𝗝𝗔𝗥𝗩𝗜𝗦 𝗔𝗖𝗖𝗘𝗦𝗦 〕─╮\n` +
                            `│ 🔐 Mode actuel : *${currentMode}*\n` +
                            `│ ${accessInfo}\n` +
                            `│\n` +
                            `│ Utilisation : *.mode public* ou *.mode private*\n` +
                            `╰──────────────────╯`,
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }

                if (action !== 'public' && action !== 'private') {
                    await sock.sendMessage(chatId, {
                        text:
                            `╭─〔 𝗡𝗘𝗫𝗢-𝗝𝗔𝗥𝗩𝗜𝗦 𝗔𝗖𝗖𝗘𝗦𝗦 〕─╮\n` +
                            `│ ⚠️ Option invalide.\n` +
                            `│ Utilisez *.mode public* ou *.mode private*.\n` +
                            `╰──────────────────╯`,
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }

                try {
                    // Update access mode
                    data.isPublic = action === 'public';

                    // Save updated data
                    fs.writeFileSync('./data/messageCount.json', JSON.stringify(data, null, 2));

                    const modeName = action.toUpperCase();
                    const modeInfo = action === 'public'
                        ? '🌐 Le bot est ouvert à tous.'
                        : '🔒 Le bot est verrouillé pour les membres et admins.';
                    await sock.sendMessage(chatId, {
                        text:
                            `╭─〔 𝗡𝗘𝗫𝗢-𝗝𝗔𝗥𝗩𝗜𝗦 𝗔𝗖𝗖𝗘𝗦𝗦 〕─╮\n` +
                            `│ ✅ Mode activé : *${modeName}*\n` +
                            `│ ${modeInfo}\n` +
                            `╰──────────────────╯`,
                        ...channelInfo
                    });
                } catch (error) {
                    console.error('Error updating access mode:', error);
                    await sock.sendMessage(chatId, {
                        text: '╭─〔 𝗡𝗘𝗫𝗢-𝗝𝗔𝗥𝗩𝗜𝗦 𝗔𝗖𝗖𝗘𝗦𝗦 〕─╮\n│ ❌ Échec de la mise à jour du mode.\n╰──────────────────╯',
                        ...channelInfo
                    });
                }
                break;
            case userMessage.startsWith('.anticall'):
                if (!senderIsOwnerOrSudo) {
                    await sock.sendMessage(chatId, {
                        text: 'Accès réservé au propriétaire ou aux sudo, Monsieur.',
                        ...channelInfo
                    }, { quoted: message });
                    break;
                }
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    await anticallCommand(sock, chatId, message, args);
                }
                break;
            case isChannelAlertCommand:
                {
                    const commandName = userMessage.toLowerCase().startsWith('.channelalert') ? '.channelalert' : '.fakeract';
                    await fakeReactCommand(sock, chatId, message, userMessage.slice(commandName.length).trim());
                }
                commandExecuted = true;
                break;
            case userMessage.startsWith('.pmblocker'):
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    await pmblockerCommand(sock, chatId, message, args);
                }
                commandExecuted = true;
                break;
            case userMessage === '.owner':
                await ownerCommand(sock, chatId, message);
                break;
            case userMessage === '.tagall':
                await tagAllCommand(sock, chatId, senderId, message);
                break;
            case userMessage === '.tagnotadmin':
                await tagNotAdminCommand(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.hidetag'):
                {
                    const messageText = rawText.slice(8).trim();
                    const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                    await hideTagCommand(sock, chatId, senderId, messageText, replyMessage, message);
                }
                break;
            case userMessage.startsWith('.tag'):
                const messageText = rawText.slice(4).trim();  // use rawText here, not userMessage
                const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
                await tagCommand(sock, chatId, senderId, messageText, replyMessage, message);
                break;
            case userMessage.startsWith('.antilink'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, {
                        text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: 'Faites-moi d\'abord administrateur du groupe, Monsieur.',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                await handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                break;
            case userMessage.startsWith('.antitag'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, {
                        text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, {
                        text: 'Faites-moi d\'abord administrateur du groupe, Monsieur.',
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                await handleAntitagCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message);
                break;
            case userMessage === '.meme':
                await memeCommand(sock, chatId, message);
                break;
            case userMessage === '.joke':
                await jokeCommand(sock, chatId, message);
                break;
            case userMessage === '.quote':
                await quoteCommand(sock, chatId, message);
                break;
            case userMessage === '.fact':
                await factCommand(sock, chatId, message, message);
                break;
            case userMessage.startsWith('.weather'):
                const city = userMessage.slice(9).trim();
                if (city) {
                    await weatherCommand(sock, chatId, message, city);
                } else {
                    await sock.sendMessage(chatId, { text: '🌦️ Indiquez une ville, Monsieur. Exemple : *.weather Kinshasa*', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage === '.news':
                await newsCommand(sock, chatId);
                break;
            case userMessage.startsWith('.ttt') || userMessage.startsWith('.tictactoe'):
                const tttText = userMessage.split(' ').slice(1).join(' ');
                await tictactoeCommand(sock, chatId, senderId, tttText);
                break;
            case userMessage.startsWith('.move'):
                const position = parseInt(userMessage.split(' ')[1]);
                if (isNaN(position)) {
                    await sock.sendMessage(chatId, { text: 'Indiquez un numéro de case valide pour le Morpion, Monsieur.', ...channelInfo }, { quoted: message });
                } else {
                    await handleTicTacToeMove(sock, chatId, senderId, String(position));
                }
                break;
            case userMessage === '.topmembers':
                await topMembers(sock, chatId, isGroup);
                break;
            case userMessage.startsWith('.hangman'):
                await startHangman(sock, chatId);
                break;
            case userMessage.startsWith('.guess'):
                const guessedLetter = userMessage.split(' ')[1];
                if (guessedLetter) {
                    await guessLetter(sock, chatId, guessedLetter);
                } else {
                    await sock.sendMessage(chatId, { text: '🔤 Proposez une lettre avec *.guess <lettre>*, Monsieur.', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage.startsWith('.trivia'):
                await startTrivia(sock, chatId);
                break;
            case userMessage.startsWith('.answer'):
                const answer = userMessage.split(' ').slice(1).join(' ');
                if (answer) {
                    await answerTrivia(sock, chatId, answer);
                } else {
                    await sock.sendMessage(chatId, { text: 'Indiquez votre réponse avec .answer <réponse>', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage.startsWith('.compliment'):
                await complimentCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.insult'):
                await insultCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.8ball'):
                const question = userMessage.split(' ').slice(1).join(' ');
                await eightBallCommand(sock, chatId, question);
                break;
            case userMessage.startsWith('.lyrics'):
                const songTitle = userMessage.split(' ').slice(1).join(' ');
                await lyricsCommand(sock, chatId, songTitle, message);
                break;
            case userMessage.startsWith('.simp'):
                const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await simpCommand(sock, chatId, quotedMsg, mentionedJid, senderId);
                break;
            case userMessage.startsWith('.stupid') || userMessage.startsWith('.itssostupid') || userMessage.startsWith('.iss'):
                const stupidQuotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                const stupidMentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                const stupidArgs = userMessage.split(' ').slice(1);
                await stupidCommand(sock, chatId, stupidQuotedMsg, stupidMentionedJid, senderId, stupidArgs);
                break;
            case userMessage === '.dare':
                await dareCommand(sock, chatId, message);
                break;
            case userMessage === '.truth':
                await truthCommand(sock, chatId, message);
                break;
            case userMessage === '.clear':
                if (isGroup) await clearCommand(sock, chatId);
                break;
            // ── .promotetime doit être AVANT .promote ──
            case userMessage.startsWith('.promotetime'):
                await promoteTimeCommand(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.promote'):
                const mentionedJidListPromote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await promoteCommand(sock, chatId, mentionedJidListPromote, message);
                break;
            case userMessage.startsWith('.demoteadmin'):
                {
                    const mentionedJidListDemoteAdmin = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
                    await demoteCommand(sock, chatId, mentionedJidListDemoteAdmin, message);
                }
                break;
            case userMessage.startsWith('.demote'):
                const mentionedJidListDemote = message.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
                await demoteCommand(sock, chatId, mentionedJidListDemote, message);
                break;
            case userMessage === '.viewtest':
                await viewTestCommand(sock, chatId, message);
                break;
            case userMessage === '.theme' || userMessage === '.themes' || userMessage.startsWith('.theme '):
                await themeCommand(sock, chatId, message, userMessage.startsWith('.theme ') ? rawText.trim().split(/\s+/).slice(1).join(' ') : '');
                break;
            case userMessage === '.menustyle' || userMessage.startsWith('.menustyle '):
                await displayCommand(sock, chatId, message, 'menuStyle', userMessage.slice(10).trim(), isOwnerOrSudoCheck);
                break;
            case userMessage === '.imagemode' || userMessage.startsWith('.imagemode '):
                await displayCommand(sock, chatId, message, 'imageReply', userMessage.slice(10).trim(), isOwnerOrSudoCheck);
                break;
            case userMessage === '.replystyle' || userMessage.startsWith('.replystyle '):
                await displayCommand(sock, chatId, message, 'replyFrame', userMessage.slice(11).trim(), isOwnerOrSudoCheck);
                break;
            case userMessage === '.preview' || userMessage.startsWith('.preview '):
                await displayCommand(sock, chatId, message, 'previewImage', userMessage.slice(8).trim(), isOwnerOrSudoCheck);
                break;
            case UTILS_COMMANDS.includes(userMessage.split(/\s+/)[0].slice(1)): {
                const utilName = userMessage.split(/\s+/)[0].slice(1);
                await utilsCommand(sock, chatId, message, utilName, userMessage);
                break;
            }
            case userMessage === '.gif' || userMessage.startsWith('.gif '):
                await gifCommand(sock, chatId, userMessage.slice(4).trim());
                break;
            case userMessage === '.addstatut' || userMessage.startsWith('.addstatut ')
                || userMessage === '.gstatus' || userMessage.startsWith('.gstatus ')
                || userMessage === '.statutgroupe' || userMessage.startsWith('.statutgroupe '):
                await addStatutCommand(sock, chatId, message, rawText.trim().split(/\s+/).slice(1).join(' '));
                break;
            case /^\.(panel|ram|gc|logs|disk|restart|config|owners|lang)(\s|$)/.test(userMessage): {
                const panelName = userMessage.slice(1).split(/\s+/)[0];
                await panelCommand(sock, chatId, message, panelName, rawText.trim().split(/\s+/).slice(1).join(' '));
                break;
            }
            case userMessage === '.fixgroup' || userMessage === '.fixgc' || userMessage === '.resync':
                await fixGroupCommand(sock, chatId, message);
                break;
            case userMessage === '.idch' || userMessage.startsWith('.idch '):
                // Le lien est sensible à la casse : on le lit dans le texte d'origine, pas dans la version en minuscules.
                await idchCommand(sock, chatId, message, rawText.trim().split(/\s+/).slice(1).join(' '));
                break;
            case userMessage === '.quotecard' || userMessage.startsWith('.quotecard '):
                await displayCommand(sock, chatId, message, 'quoteCard', userMessage.slice(10).trim(), isOwnerOrSudoCheck);
                break;
            case userMessage === '.pair' || userMessage.startsWith('.pair '):
                await pairCommand(sock, chatId, message, userMessage.slice(5).trim());
                break;
            case userMessage === '.ping':
                await pingCommand(sock, chatId, message);
                break;
            case userMessage === '.alive':
                await aliveCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.mention '):
                {
                    const args = userMessage.split(' ').slice(1).join(' ');
                    const isOwner = senderIsOwnerOrSudo;
                    await mentionToggleCommand(sock, chatId, message, args, isOwner);
                }
                break;
            case userMessage === '.setmention':
                {
                    const isOwner = senderIsOwnerOrSudo;
                    await setMentionCommand(sock, chatId, message, isOwner);
                }
                break;
            case userMessage.startsWith('.blur'):
                const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
                await blurCommand(sock, chatId, message, quotedMessage);
                break;
            case userMessage.startsWith('.welcome'):
                if (isGroup) {
                    // Check admin status if not already checked
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (isSenderAdmin || message.key.fromMe) {
                        await welcomeCommand(sock, chatId, message);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Seuls les admins peuvent utiliser cette commande.', ...channelInfo }, { quoted: message });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage.startsWith('.goodbye'):
                if (isGroup) {
                    // Check admin status if not already checked
                    if (!isSenderAdmin) {
                        const adminStatus = await isAdmin(sock, chatId, senderId);
                        isSenderAdmin = adminStatus.isSenderAdmin;
                    }

                    if (isSenderAdmin || message.key.fromMe) {
                        await goodbyeCommand(sock, chatId, message);
                    } else {
                        await sock.sendMessage(chatId, { text: 'Seuls les admins peuvent utiliser cette commande.', ...channelInfo }, { quoted: message });
                    }
                } else {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                }
                break;
            case userMessage === '.git':
            case userMessage === '.github':
            case userMessage === '.sc':
            case userMessage === '.script':
                await githubCommand(sock, chatId, message);
                break;
            case userMessage === '.repo':
                await repoCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.antibot'): {
                const antibotArgs = userMessage.split(' ').slice(1);
                const adminStatus2 = await isAdmin(sock, chatId, senderId);
                await antibotCommand(sock, chatId, message, antibotArgs, adminStatus2.isSenderAdmin || message.key.fromMe || senderIsOwnerOrSudo);
                break;
            }
            case userMessage.startsWith('.antibadword'):
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                    return;
                }

                const adminStatus = await isAdmin(sock, chatId, senderId);
                isSenderAdmin = adminStatus.isSenderAdmin;
                isBotAdmin = adminStatus.isBotAdmin;

                if (!isBotAdmin) {
                    await sock.sendMessage(chatId, { text: '*Je dois être administrateur pour utiliser cette fonction, Monsieur*', ...channelInfo }, { quoted: message });
                    return;
                }

                await antibadwordCommand(sock, chatId, message, senderId, isSenderAdmin);
                break;
            case userMessage.startsWith('.chatbot'):
                {
                    const chatbotAdminStatus = isGroup
                        ? await isAdmin(sock, chatId, senderId)
                        : { isSenderAdmin: false };
                    const canConfigureChatbot = message.key.fromMe || senderIsOwnerOrSudo || chatbotAdminStatus.isSenderAdmin;
                    if (!canConfigureChatbot) {
                        await sock.sendMessage(chatId, {
                            text: isGroup
                                ? '*Réservé aux administrateurs ou au propriétaire du système, Monsieur*'
                                : '*Seul le propriétaire peut configurer le chatbot en privé, Monsieur*',
                            ...channelInfo
                        }, { quoted: message });
                        break;
                    }
                    const match = userMessage.slice('.chatbot'.length).trim();
                    await handleChatbotCommand(sock, chatId, message, match, {
                        isOwner: message.key.fromMe || senderIsOwnerOrSudo,
                        isAdmin: chatbotAdminStatus.isSenderAdmin
                    });
                }
                break;
            case userMessage.startsWith('.take') || userMessage.startsWith('.steal'):
                {
                    const isSteal = userMessage.startsWith('.steal');
                    const sliceLen = isSteal ? 6 : 5; // '.steal' vs '.take'
                    const takeArgs = rawText.slice(sliceLen).trim().split(' ');
                    await takeCommand(sock, chatId, message, takeArgs);
                }
                break;
            case userMessage === '.flirt':
                await flirtCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.character'):
                await characterCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.wasted') || userMessage.startsWith('.waste'):
                await wastedCommand(sock, chatId, message);
                break;
            case userMessage === '.ship':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                    return;
                }
                await shipCommand(sock, chatId, message);
                break;
            case userMessage === '.groupinfo' || userMessage === '.infogp' || userMessage === '.infogrupo':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                    return;
                }
                await groupInfoCommand(sock, chatId, message);
                break;
            case userMessage === '.profile' || userMessage === '.profil':
                await profileCommand(sock, chatId, message);
                break;
            case userMessage === '.resetlink' || userMessage === '.revoke' || userMessage === '.anularlink':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                    return;
                }
                await resetlinkCommand(sock, chatId, senderId);
                break;
            case userMessage === '.staff' || userMessage === '.admins' || userMessage === '.listadmin':
                if (!isGroup) {
                    await sock.sendMessage(chatId, { text: 'Cette fonction n\'est disponible qu\'en groupe, Monsieur.', ...channelInfo }, { quoted: message });
                    return;
                }
                await staffCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.tourl') || userMessage.startsWith('.url'):
                await urlCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.emojimix') || userMessage.startsWith('.emix'):
                await emojimixCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.tg') || userMessage.startsWith('.stickertelegram') || userMessage.startsWith('.tgsticker') || userMessage.startsWith('.telesticker'):
                await stickerTelegramCommand(sock, chatId, message);
                break;

            // .vv → renvoie le média dans la discussion actuelle
            case userMessage === '.vv':
            case userMessage === '.🥷':
                await vvCommand(sock, chatId, message, false);
                commandExecuted = true;
                break;
            // .vv2 → envoie le média directement en PV de l'expéditeur
            case userMessage === '.vv2':
                await vvCommand(sock, chatId, message, true);
                commandExecuted = true;
                break;
            case userMessage === '.clearsession' || userMessage === '.clearsesi':
                await clearSessionCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.autostatus'):
                const autoStatusArgs = userMessage.split(' ').slice(1);
                await autoStatusCommand(sock, chatId, message, autoStatusArgs);
                break;
            case userMessage.startsWith('.simp'):
                await simpCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.metallic'):
                await textmakerCommand(sock, chatId, message, userMessage, 'metallic');
                break;
            case userMessage.startsWith('.ice'):
                await textmakerCommand(sock, chatId, message, userMessage, 'ice');
                break;
            case userMessage.startsWith('.snow'):
                await textmakerCommand(sock, chatId, message, userMessage, 'snow');
                break;
            case userMessage.startsWith('.impressive'):
                await textmakerCommand(sock, chatId, message, userMessage, 'impressive');
                break;
            case userMessage.startsWith('.matrix'):
                await textmakerCommand(sock, chatId, message, userMessage, 'matrix');
                break;
            case userMessage.startsWith('.light'):
                await textmakerCommand(sock, chatId, message, userMessage, 'light');
                break;
            case userMessage.startsWith('.neon'):
                await textmakerCommand(sock, chatId, message, userMessage, 'neon');
                break;
            case userMessage.startsWith('.devil'):
                await textmakerCommand(sock, chatId, message, userMessage, 'devil');
                break;
            case userMessage.startsWith('.purple'):
                await textmakerCommand(sock, chatId, message, userMessage, 'purple');
                break;
            case userMessage.startsWith('.thunder'):
                await textmakerCommand(sock, chatId, message, userMessage, 'thunder');
                break;
            case userMessage.startsWith('.leaves'):
                await textmakerCommand(sock, chatId, message, userMessage, 'leaves');
                break;
            case userMessage.startsWith('.1917'):
                await textmakerCommand(sock, chatId, message, userMessage, '1917');
                break;
            case userMessage.startsWith('.arena'):
                await textmakerCommand(sock, chatId, message, userMessage, 'arena');
                break;
            case userMessage.startsWith('.hacker'):
                await textmakerCommand(sock, chatId, message, userMessage, 'hacker');
                break;
            case userMessage.startsWith('.sand'):
                await textmakerCommand(sock, chatId, message, userMessage, 'sand');
                break;
            case userMessage.startsWith('.blackpink'):
                await textmakerCommand(sock, chatId, message, userMessage, 'blackpink');
                break;
            case userMessage.startsWith('.glitch'):
                await textmakerCommand(sock, chatId, message, userMessage, 'glitch');
                break;
            case userMessage.startsWith('.fire'):
                await textmakerCommand(sock, chatId, message, userMessage, 'fire');
                break;
            case userMessage.startsWith('.antidelete'):
                const antideleteMatch = userMessage.slice(11).trim();
                await handleAntideleteCommand(sock, chatId, message, antideleteMatch);
                break;
            case userMessage === '.surrender':
                // Handle surrender command for tictactoe game
                await handleTicTacToeMove(sock, chatId, senderId, 'surrender');
                break;
            case userMessage === '.cleartmp':
                await clearTmpCommand(sock, chatId, message);
                break;
            case userMessage === '.setpp':
                await setProfilePicture(sock, chatId, message);
                break;
            case userMessage.startsWith('.setgdesc'):
                {
                    const text = rawText.slice(9).trim();
                    await setGroupDescription(sock, chatId, senderId, text, message);
                }
                break;
            case userMessage.startsWith('.setgname'):
                {
                    const text = rawText.slice(9).trim();
                    await setGroupName(sock, chatId, senderId, text, message);
                }
                break;
            case userMessage.startsWith('.setgpp'):
                await setGroupPhoto(sock, chatId, senderId, message);
                break;
            case userMessage.startsWith('.instagram') || userMessage.startsWith('.insta') || (userMessage === '.ig' || userMessage.startsWith('.ig ')):
                await withProgress(instagramCommand, { icon: '📸' })(sock, chatId, message);
                break;
            case userMessage.startsWith('.igsc'):
                await withProgress(igsCommand, { icon: '📸' })(sock, chatId, message, true);
                break;
            case userMessage.startsWith('.igs'):
                await withProgress(igsCommand, { icon: '📸' })(sock, chatId, message, false);
                break;
            case userMessage.startsWith('.fb') || userMessage.startsWith('.facebook'):
                await withProgress(facebookCommand, { icon: '🎬' })(sock, chatId, message);
                break;
            case userMessage.startsWith('.music'):
                await playCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.spotify'):
                await spotifyCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.ytdl '):
                await ytdlCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.play') || userMessage.startsWith('.mp3') || userMessage.startsWith('.ytmp3') || userMessage.startsWith('.song'):
                await songCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.video') || userMessage.startsWith('.ytmp4'):
                await videoCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.tiktok') || userMessage.startsWith('.tt'):
                await withProgress(tiktokCommand, { icon: '🎵' })(sock, chatId, message);
                break;
            case userMessage.startsWith('.gpt') || userMessage.startsWith('.gemini') || userMessage === '.ai' || userMessage.startsWith('.ai '):
                await aiCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.translate') || userMessage.startsWith('.trt'):
                const commandLength = userMessage.startsWith('.translate') ? 10 : 4;
                await handleTranslateCommand(sock, chatId, message, userMessage.slice(commandLength));
                return;
            case userMessage.startsWith('.ss') || userMessage.startsWith('.ssweb') || userMessage.startsWith('.screenshot'):
                const ssCommandLength = userMessage.startsWith('.screenshot') ? 11 : (userMessage.startsWith('.ssweb') ? 6 : 3);
                await handleSsCommand(sock, chatId, message, userMessage.slice(ssCommandLength).trim());
                break;
            case userMessage.startsWith('.areact') || userMessage.startsWith('.autoreact') || userMessage.startsWith('.autoreaction'):
                await handleAreactCommand(sock, chatId, message, isOwnerOrSudoCheck);
                break;
            case userMessage.startsWith('.sudo'):
                await sudoCommand(sock, chatId, message);
                break;
            case userMessage === '.goodnight' || userMessage === '.lovenight' || userMessage === '.gn':
                await goodnightCommand(sock, chatId, message);
                break;
            case userMessage === '.shayari' || userMessage === '.shayri':
                await shayariCommand(sock, chatId, message);
                break;
            case userMessage === '.roseday':
                await rosedayCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.imagine') || userMessage.startsWith('.flux') || userMessage.startsWith('.dalle'): await imagineCommand(sock, chatId, message);
                break;
            case userMessage === '.jid': await groupJidCommand(sock, chatId, message);
                break;
            case userMessage.startsWith('.autotyping'):
                await autotypingCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.autoread'):
                await autoreadCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.heart'):
                await handleHeart(sock, chatId, message);
                break;
            case userMessage.startsWith('.horny'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['horny', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.circle'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['circle', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.lgbt'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['lgbt', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.lolice'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['lolice', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.simpcard'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['simpcard', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.tonikawa'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['tonikawa', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.its-so-stupid'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['its-so-stupid', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.namecard'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['namecard', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;

            case userMessage.startsWith('.oogway2'):
            case userMessage.startsWith('.oogway'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const sub = userMessage.startsWith('.oogway2') ? 'oogway2' : 'oogway';
                    const args = [sub, ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.tweet'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['tweet', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.ytcomment'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = ['youtube-comment', ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.comrade'):
            case userMessage.startsWith('.gay'):
            case userMessage.startsWith('.glass'):
            case userMessage.startsWith('.jail'):
            case userMessage.startsWith('.passed'):
            case userMessage.startsWith('.triggered'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const sub = userMessage.slice(1).split(/\s+/)[0];
                    const args = [sub, ...parts.slice(1)];
                    await miscCommand(sock, chatId, message, args);
                }
                break;
            case userMessage.startsWith('.animu'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    const args = parts.slice(1);
                    await animeCommand(sock, chatId, message, args);
                }
                break;
            // animu aliases
            case userMessage.startsWith('.nom'):
            case userMessage.startsWith('.poke'):
            case userMessage.startsWith('.cry'):
            case userMessage.startsWith('.kiss'):
            case userMessage.startsWith('.pat'):
            case userMessage.startsWith('.hug'):
            case userMessage.startsWith('.wink'):
            case userMessage.startsWith('.facepalm'):
            case userMessage.startsWith('.face-palm'):
            case userMessage.startsWith('.animuquote'):
            case userMessage.startsWith('.quote'):
            case userMessage.startsWith('.loli'):
                {
                    const parts = userMessage.trim().split(/\s+/);
                    let sub = parts[0].slice(1);
                    if (sub === 'facepalm') sub = 'face-palm';
                    if (sub === 'quote' || sub === 'animuquote') sub = 'quote';
                    await animeCommand(sock, chatId, message, [sub]);
                }
                break;
            case userMessage === '.crop':
                await stickercropCommand(sock, chatId, message);
                commandExecuted = true;
                break;
            case userMessage.startsWith('.pies'):
                {
                    const parts = rawText.trim().split(/\s+/);
                    const args = parts.slice(1);
                    await piesCommand(sock, chatId, message, args);
                    commandExecuted = true;
                }
                break;
            case userMessage === '.china':
                await piesAlias(sock, chatId, message, 'china');
                commandExecuted = true;
                break;
            case userMessage === '.indonesia':
                await piesAlias(sock, chatId, message, 'indonesia');
                commandExecuted = true;
                break;
            case userMessage === '.japan':
                await piesAlias(sock, chatId, message, 'japan');
                commandExecuted = true;
                break;
            case userMessage === '.korea':
                await piesAlias(sock, chatId, message, 'korea');
                commandExecuted = true;
                break;
            case userMessage === '.india':
                await piesAlias(sock, chatId, message, 'india');
                commandExecuted = true;
                break;
            case userMessage === '.malaysia':
                await piesAlias(sock, chatId, message, 'malaysia');
                commandExecuted = true;
                break;
            case userMessage === '.thailand':
                await piesAlias(sock, chatId, message, 'thailand');
                commandExecuted = true;
                break;
            case userMessage.startsWith('.update'):
                {
                    const parts = rawText.trim().split(/\s+/);
                    const zipArg = parts[1] && parts[1].startsWith('http') ? parts[1] : '';
                    await updateCommand(sock, chatId, message, zipArg);
                }
                commandExecuted = true;
                break;
            case userMessage.startsWith('.removebg') || userMessage.startsWith('.rmbg') || userMessage.startsWith('.nobg'):
                await removebgCommand.exec(sock, message, userMessage.split(' ').slice(1));
                break;
            case userMessage.startsWith('.remini') || userMessage.startsWith('.enhance') || userMessage.startsWith('.upscale'):
                await reminiCommand(sock, chatId, message, userMessage.split(' ').slice(1));
                break;
            case userMessage.startsWith('.sora'):
                await soraCommand(sock, chatId, message);
                break;

            // ── Open / Close groupe ──────────────────────────────────────────
            case userMessage === '.open':
                await openGroupCommand(sock, chatId, message);
                break;
            case userMessage === '.close':
                await closeGroupCommand(sock, chatId, message);
                break;

            // ── NOUVELLES PROTECTIONS GROUPE ───────────────────────────────
            case userMessage.startsWith('.antiflood') || userMessage.startsWith('.antispam') || userMessage.startsWith('.antimedia') || userMessage.startsWith('.antisticker') || userMessage.startsWith('.antivoice'):
                {
                    const antiFeature = userMessage.split(/\s+/)[0].slice(1);
                    await groupAntiCommand(sock, chatId, message, userMessage.split(/\s+/).slice(1), antiFeature, isSenderAdmin);
                }
                break;

            // ── ANTIPROMOTE ──────────────────────────────────────────────────
            case userMessage.startsWith('.antipromote'):
                {
                    const apArgs = userMessage.split(' ').slice(1).join(' ');
                    await antiPromoteCommand(sock, chatId, senderId, message, apArgs);
                }
                break;

            // ── ANTIMENTIONGC ────────────────────────────────────────────────
            case userMessage.startsWith('.antimentiongc'):
                {
                    const amgcArgs = userMessage.split(' ').slice(1).join(' ');
                    await antiMentionGcCommand(sock, chatId, senderId, message, amgcArgs);
                }
                break;


            default:
                if (isGroup) {
                    // Handle non-command group messages
                    if (userMessage) {  // Make sure there's a message
                        await handleChatbotResponse(sock, chatId, message, userMessage, senderId);
                    }
                    await handleTagDetection(sock, chatId, message, senderId);
                    await handleMentionDetection(sock, chatId, message);
                }
                commandExecuted = false;
                break;
        }

        // ── Clear typing presence after command completes ───────────────────
        sock.sendPresenceUpdate('paused', chatId).catch(() => {});

        // If a command was executed, show typing status after command execution
        if (commandExecuted !== false) {
            await showTypingAfterCommand(sock, chatId);
        }

        // Function to handle .groupjid command
        async function groupJidCommand(sock, chatId, message) {
            const groupJid = message.key.remoteJid;

            if (!groupJid.endsWith('@g.us')) {
                return await sock.sendMessage(chatId, {
                    text: "❌ Cette fonction n\'est disponible qu\'en groupe, Monsieur."
                });
            }

            await sock.sendMessage(chatId, {
                text: `✅ Group JID: ${groupJid}`
            }, {
                quoted: message
            });
        }

    } catch (error) {
        console.error('❌ Error in message handler:', error.message);
        // Only try to send error message if we have a valid chatId
        if (chatId) {
            await sock.sendMessage(chatId, {
                text: '❌ Le traitement de la commande a échoué, Monsieur.',
                ...channelInfo
            });
        }
    }
}

async function handleGroupParticipantUpdate(sock, update) {
    try {
        const { id, participants, action, author } = update;

        // Check if it's a group
        if (!id.endsWith('@g.us')) return;

        // Respect bot mode: only announce promote/demote in public mode
        let isPublic = true;
        try {
            const modeData = JSON.parse(fs.readFileSync('./data/messageCount.json'));
            if (typeof modeData.isPublic === 'boolean') isPublic = modeData.isPublic;
        } catch (e) {
            // If reading fails, default to public behavior
        }

        // Handle promotion events
        if (action === 'promote') {
            // Antipromote : démis automatiquement même en mode privé
            const wasBlocked = await handleAntiPromoteEvent(sock, id, participants);
            if (wasBlocked) return; // déjà géré, pas d'annonce normale
            if (!isPublic) return;
            await handlePromotionEvent(sock, id, participants, author);
            return;
        }

        // Handle demotion events
        if (action === 'demote') {
            if (!isPublic) return;
            await handleDemotionEvent(sock, id, participants, author);
            return;
        }

        // Handle join events
        if (action === 'add') {
            await handleJoinEvent(sock, id, participants, author);
        }

        // Handle leave events
        if (action === 'remove') {
            await handleLeaveEvent(sock, id, participants, author);
        }
    } catch (error) {
        console.error('Error in handleGroupParticipantUpdate:', error);
    }
}

// Instead, export the handlers along with handleMessages
module.exports = {
    handleMessages,
    handleGroupParticipantUpdate,
    restoreHijackTimers,
    handleStatus: async (sock, status) => {
        await handleStatusUpdate(sock, status);
    }
};
