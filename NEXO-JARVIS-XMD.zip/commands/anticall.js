const { channelInfo } = require('../lib/messageConfig');

function sendAntiMessage(sock, chatId, content, options) {
    const forwarded = content && (content.text || content.caption || content.image || content.video || content.audio || content.sticker || content.document)
        ? { ...content, ...channelInfo }
        : content;
    return sock.sendMessage(chatId, forwarded, options);
}

const fs = require('fs');

const ANTICALL_PATH = './data/anticall.json';

function readState() {
    try {
        if (!fs.existsSync(ANTICALL_PATH)) return { activé: false, enabled: false };
        const raw = fs.readFileSync(ANTICALL_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        const on = !!(data.activé ?? data.enabled);
        return { activé: on, enabled: on };   // les deux clés : anciens fichiers et lecteurs externes
    } catch {
        return { activé: false, enabled: false };
    }
}

function writeState(activé) {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
        fs.writeFileSync(ANTICALL_PATH, JSON.stringify({ activé: !!activé, enabled: !!activé }, null, 2));
    } catch {}
}

async function anticallCommand(sock, chatId, message, args) {
    const state = readState();
    const sub = (args || '').trim().toLowerCase();

    if (!sub || (sub !== 'on' && sub !== 'off' && sub !== 'status')) {
        await sendAntiMessage(sock, chatId, { text: '*ANTICALL*\n\n.anticall on  - Activer le blocage automatique des appels entrants\n.anticall off - Désactiver l\'anticall\n.anticall status - Afficher l\'état actuel' }, { quoted: message });
        return;
    }

    if (sub === 'status') {
        await sendAntiMessage(sock, chatId, { text: `Anticall is currently *${state.activé ? 'ACTIF' : 'INACTIF'}*.` }, { quoted: message });
        return;
    }

    const enable = sub === 'on';
    writeState(enable);
    await sendAntiMessage(sock, chatId, { text: `Anticall : *${enable ? 'ACTIVÉ' : 'DÉSACTIVÉ'}*.` }, { quoted: message });
}

module.exports = { anticallCommand, readState };


